
import React from 'react';

const projects = [
  {
    title: 'E‑Commerce Store',
    description: 'Laravel + MySQL shop with admin, cart and Payment.',
image: '/images/ecommerce.png',
    tags: ['TailwindCSS','Ajax','jQuery','Laravel', 'MySQL'],
  },
  {
    title: 'School Management System',
    description: 'Dynamic CMS with auth, CRUD, categories & REST API.',
image: '/images/SMS.png',
    tags: [ 'Laravel', 'REST', 'MySQL'],
  },
  {
    title: 'Blog CMS',
    description: 'Dynamic posts, auth, and dashboard using Laravel.',
image: '/images/blog.png',
    tags: ['Laravel', 'Blade', 'REST'],
  },
];

const ProjectCard: React.FC<{ project: typeof projects[0], delay: number }> = ({ project, delay }) => (
  <article 
    className="bg-gray-900 rounded-2xl overflow-hidden border border-white/5 hover:border-cyan-500/40 transition group shadow-lg" 
    data-aos="fade-up"
    data-aos-delay={delay}
  >
    <img src={project.image} alt={project.title} className="h-44 w-full object-cover group-hover:scale-[1.02] transition-transform duration-300" />
    <div className="p-6">
      <h4 className="text-xl font-semibold text-cyan-400">{project.title}</h4>
      <p className="mt-2 text-gray-400">{project.description}</p>
      <div className="mt-3 flex flex-wrap gap-2">
        {project.tags.map(tag => (
          <span key={tag} className="px-2 py-1 rounded tag bg-gray-800 text-xs font-medium">{tag}</span>
        ))}
      </div>
    </div>
  </article>
);


const Projects: React.FC = () => {
  return (
    <section id="projects" className="py-20">
      <h3 className="text-4xl font-bold text-center mb-12 gradient-text">Projects</h3>
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 px-6">
        {projects.map((project, index) => (
          <ProjectCard key={project.title} project={project} delay={index * 100} />
        ))}
      </div>
    </section>
  );
};

export default Projects;
