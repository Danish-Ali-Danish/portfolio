
import React from 'react';

const Contact: React.FC = () => {
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    // In a real app, you'd handle form submission here.
    alert('Thank you for your message!');
  };

  return (
    <section id="contact" className="py-20 bg-gray-900">
      <h2 className="text-4xl font-bold text-center mb-12 gradient-text">Contact Me</h2>
      <div className="max-w-2xl mx-auto bg-gray-800 rounded-2xl p-8 shadow-lg" data-aos="zoom-in">
        <form className="space-y-4" onSubmit={handleSubmit}>
          <input type="text" placeholder="Your Name" required className="w-full bg-gray-900 px-4 py-3 rounded-lg border border-gray-700 focus:outline-none focus:ring-2 focus:ring-cyan-500 transition"/>
          <input type="email" placeholder="Your Email" required className="w-full bg-gray-900 px-4 py-3 rounded-lg border border-gray-700 focus:outline-none focus:ring-2 focus:ring-cyan-500 transition"/>
          <textarea placeholder="Your Message" rows={4} required className="w-full bg-gray-900 px-4 py-3 rounded-lg border border-gray-700 focus:outline-none focus:ring-2 focus:ring-cyan-500 transition"></textarea>
          <button type="submit" className="hvr-bounce-to-top w-full bg-gradient-to-r from-cyan-600 to-pink-600 py-3 rounded-lg font-semibold text-white">Send</button>
        </form>
        <div className="flex justify-center space-x-6 mt-6 text-2xl text-gray-400">
          <a href="#" className="hvr-grow" aria-label="GitHub"><i className='bx bxl-github hover:text-white transition'></i></a>
          <a href="#" className="hvr-grow" aria-label="LinkedIn"><i className='bx bxl-linkedin hover:text-blue-400 transition'></i></a>
          <a href="#" className="hvr-grow" aria-label="Facebook"><i className='bx bxl-facebook hover:text-blue-600 transition'></i></a>
        </div>
      </div>
    </section>
  );
};

export default Contact;
