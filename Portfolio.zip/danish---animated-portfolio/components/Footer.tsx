
import React from 'react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();
  return (
    <footer className="bg-gray-950 text-gray-500 text-center py-6">
      <p>© {currentYear} Danish.dev | Crafted with ❤ using React, Tailwind, & more</p>
    </footer>
  );
};

export default Footer;
