
import React, { useEffect, useRef } from 'react';

// Since Typed.js and tsParticles are loaded from a CDN, we declare them for TypeScript
declare const Typed: any;
declare const tsParticles: any;

const Hero: React.FC = () => {
  const typedEl = useRef<HTMLSpanElement>(null);
  const particlesInitialized = useRef(false);

  useEffect(() => {
    const typed = new Typed(typedEl.current, {
      strings: ['Web Developer', 'Full Stack Engineer', 'Laravel Expert', 'MySQL Specialist', 'UI/UX Enthusiast'],
      typeSpeed: 80,
      backSpeed: 50,
      loop: true,
      smartBackspace: true,
    });

    // Cleanup on component unmount
    return () => {
      typed.destroy();
    };
  }, []);
  
  useEffect(() => {
    if (!particlesInitialized.current) {
        tsParticles.load("particles-js", {
            background: { color: "transparent" },
            particles: {
                number: { value: 60 },
                color: { value: ["#06b6d4", "#9333ea", "#f43f5e"] },
                shape: { type: "circle" },
                opacity: { value: 0.6 },
                size: { value: { min: 1, max: 4 } },
                move: { enable: true, speed: 2, direction: "none", random: false, straight: false, out_mode: "out" },
                links: { enable: true, distance: 150, color: "#888", opacity: 0.4, width: 1 }
            },
            interactivity: {
                events: {
                    onHover: { enable: true, mode: "repulse" },
                    onClick: { enable: true, mode: "push" },
                },
                modes: {
                    repulse: { distance: 100 },
                    push: { quantity: 4 }
                }
            }
        });
        particlesInitialized.current = true;
    }
  }, []);

  return (
    <section id="hero" className="min-h-screen flex items-center justify-center text-center relative overflow-hidden px-6">
      <div id="particles-js"></div>
      <div className="relative z-10 max-w-3xl" data-aos="fade-up">
        <h2 className="text-5xl md:text-7xl font-extrabold gradient-text">Hi! I'm Danish</h2>
        <p className="mt-3 text-xl md:text-2xl text-gray-300"><span ref={typedEl}></span></p>
        <p className="mt-8 text-lg md:text-xl text-gray-300 leading-relaxed border-l-4 border-cyan-500 pl-4 text-left max-w-md mx-auto">
          I’m a Laravel & MySQL specialist crafting fast, modern, and scalable web apps with clean UI/UX.
        </p>
        <div className="mt-8 flex items-center justify-center gap-4">
          <a href="#projects" className="hvr-bounce-to-right px-6 py-3 bg-cyan-600 rounded-full font-semibold text-white no-underline">See Projects</a>
          <a href="#contact" className="hvr-bounce-to-left px-6 py-3 bg-pink-600 rounded-full font-semibold text-white no-underline">Hire Me</a>
        </div>
      </div>
    </section>
  );
};

export default Hero;
