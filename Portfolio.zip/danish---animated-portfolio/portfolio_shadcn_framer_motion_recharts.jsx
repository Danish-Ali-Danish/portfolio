// /src/app/Portfolio.tsx
// Minimal-dependency portfolio using Tailwind, shadcn/ui, framer-motion, lucide-react, and recharts.
// NOTE: Ensure Tailwind + shadcn/ui are configured in your project. This file exports a single component.

import React, { useEffect, useMemo, useRef, useState } from "react";
import { motion } from "framer-motion";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import {
  Github,
  Linkedin,
  Mail,
  ExternalLink,
  Download,
  Sun,
  Moon,
  ArrowRight,
  Laptop,
  Smartphone,
  Sparkles,
} from "lucide-react";
import {
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  ResponsiveContainer,
} from "recharts";

// ---- Utility & Theme Toggle ----
function useDarkMode() {
  const [enabled, setEnabled] = useState(false);
  useEffect(() => {
    const stored = localStorage.getItem("theme:dark") === "true";
    setEnabled(stored);
    document.documentElement.classList.toggle("dark", stored);
  }, []);
  useEffect(() => {
    document.documentElement.classList.toggle("dark", enabled);
    localStorage.setItem("theme:dark", String(enabled));
  }, [enabled]);
  return { enabled, setEnabled } as const;
}

const fadeIn = {
  hidden: { opacity: 0, y: 12 },
  show: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } },
};

// ---- Data ----
const skillsData = [
  { subject: "React", A: 92 },
  { subject: "TypeScript", A: 88 },
  { subject: "Node.js", A: 84 },
  { subject: "UX/UI", A: 80 },
  { subject: "Testing", A: 78 },
  { subject: "DevOps", A: 72 },
];

const projects = [
  {
    title: "DesignOps Dashboard",
    desc: "Design system analytics with token governance & audit trails.",
    tags: ["Next.js", "tRPC", "Tailwind", "Prisma"],
    href: "#",
    repo: "#",
    image:
      "https://images.unsplash.com/photo-1556157382-97eda2d62296?q=80&w=1200&auto=format&fit=crop",
  },
  {
    title: "Mobile Habit Coach",
    desc: "Gamified habit app with streaks, reminders, and insights.",
    tags: ["Expo", "React Native", "Zustand"],
    href: "#",
    repo: "#",
    image:
      "https://images.unsplash.com/photo-1547658719-54cb785dbd5a?q=80&w=1200&auto=format&fit=crop",
  },
  {
    title: "AI Content Curator",
    desc: "Topic clustering, embeddings, and editorial workflow.",
    tags: ["Python", "FastAPI", "Postgres", "OpenAI"],
    href: "#",
    repo: "#",
    image:
      "https://images.unsplash.com/photo-1498050108023-c5249f4df085?q=80&w=1200&auto=format&fit=crop",
  },
];

const experience = [
  {
    role: "Senior Frontend Engineer",
    company: "Acme Corp",
    period: "2023 — Present",
    points: [
      "Led migration to React Server Components and app router.",
      "Introduced design tokens; reduced CSS by 37%.",
    ],
  },
  {
    role: "Product Engineer",
    company: "Studio Labs",
    period: "2021 — 2023",
    points: [
      "Built multi-tenant dashboard with granular RBAC.",
      "Shipped A/B testing platform; +12% conversion.",
    ],
  },
  {
    role: "Frontend Developer",
    company: "Startly",
    period: "2019 — 2021",
    points: [
      "Created component library; 85% reuse across apps.",
      "Optimized images and bundles; -48% LCP.",
    ],
  },
];

// ---- Components ----
function SectionHeading({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div className="mb-8 flex items-end justify-between">
      <div>
        <h2 className="text-2xl md:text-3xl font-bold tracking-tight">{title}</h2>
        {subtitle && <p className="text-muted-foreground mt-1">{subtitle}</p>}
      </div>
      <div className="h-px flex-1 mx-4 bg-gradient-to-r from-transparent via-muted-foreground/20 to-transparent" />
    </div>
  );
}

function Navbar({ onToggleTheme }: { onToggleTheme: () => void }) {
  const links = [
    { id: "about", label: "About" },
    { id: "projects", label: "Projects" },
    { id: "skills", label: "Skills" },
    { id: "experience", label: "Experience" },
    { id: "contact", label: "Contact" },
  ];

  const handleClick = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <div className="sticky top-0 z-50 backdrop-blur supports-[backdrop-filter]:bg-background/70 border-b">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-primary" />
          <span className="font-semibold">My Portfolio</span>
        </div>
        <div className="hidden md:flex items-center gap-2">
          {links.map((l) => (
            <Button key={l.id} variant="ghost" className="rounded-2xl" onClick={() => handleClick(l.id)}>
              {l.label}
            </Button>
          ))}
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button size="icon" variant="ghost" onClick={onToggleTheme} aria-label="Toggle theme">
                  <Sun className="h-5 w-5 dark:hidden" />
                  <Moon className="h-5 w-5 hidden dark:block" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>Toggle dark mode</TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      </div>
    </div>
  );
}

function Hero() {
  return (
    <section className="relative overflow-hidden">
      <div className="absolute inset-0 -z-10 opacity-30 dark:opacity-40 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/40 via-transparent to-transparent" />
      <div className="max-w-6xl mx-auto px-4 py-16 md:py-24 grid md:grid-cols-2 gap-10 items-center">
        <motion.div variants={fadeIn} initial="hidden" animate="show" className="space-y-6">
          <Badge className="rounded-2xl">Available for work</Badge>
          <h1 className="text-4xl md:text-6xl font-extrabold leading-tight">
            Designer–Developer crafting <span className="text-primary">delightful</span> web experiences
          </h1>
          <p className="text-muted-foreground md:text-lg">
            I build fast, accessible products with a focus on system design, performance, and developer experience.
          </p>
          <div className="flex gap-3">
            <Button size="lg" className="rounded-2xl">
              View Projects <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
            <Button size="lg" variant="outline" className="rounded-2xl">
              Download CV <Download className="ml-2 h-4 w-4" />
            </Button>
          </div>
          <div className="flex gap-2 pt-2">
            <Button asChild variant="ghost" className="rounded-2xl">
              <a href="#" aria-label="GitHub">
                <Github className="h-5 w-5" />
              </a>
            </Button>
            <Button asChild variant="ghost" className="rounded-2xl">
              <a href="#" aria-label="LinkedIn">
                <Linkedin className="h-5 w-5" />
              </a>
            </Button>
            <Button asChild variant="ghost" className="rounded-2xl">
              <a href="#contact" aria-label="Mail">
                <Mail className="h-5 w-5" />
              </a>
            </Button>
          </div>
        </motion.div>
        <motion.div variants={fadeIn} initial="hidden" animate="show">
          <Card className="rounded-3xl shadow-xl">
            <CardContent className="p-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  <img
                    src="https://images.unsplash.com/photo-1531297484001-80022131f5a1?q=80&w=1600&auto=format&fit=crop"
                    alt="workspace"
                    className="rounded-2xl object-cover h-48 w-full"
                  />
                </div>
                <Stat icon={<Laptop className="h-4 w-4" />} label="Web Apps" value="48+" />
                <Stat icon={<Smartphone className="h-4 w-4" />} label="Mobile" value="7" />
                <Stat icon={<Sparkles className="h-4 w-4" />} label="Design Systems" value="3" />
                <Stat icon={<Github className="h-4 w-4" />} label="Open Source" value="120★" />
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}

function Stat({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <Card className="rounded-2xl">
      <CardContent className="p-4">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-primary/10 text-primary">{icon}</div>
          <div>
            <div className="text-sm text-muted-foreground">{label}</div>
            <div className="text-xl font-semibold">{value}</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function About() {
  return (
    <section id="about" className="max-w-6xl mx-auto px-4 py-16">
      <SectionHeading title="About" subtitle="Who I am & how I work" />
      <div className="grid md:grid-cols-3 gap-6">
        <Card className="rounded-3xl md:col-span-2">
          <CardContent className="p-6 space-y-4">
            <p>
              I’m a product-minded engineer bridging design and development. I care about accessibility, pragmatic
              architecture, and maintainable systems.
            </p>
            <p>
              My toolkit spans React, TypeScript, Node.js, and cloud-native tooling. I love shipping thoughtfully-crafted
              experiences.
            </p>
            <div className="flex flex-wrap gap-2 pt-2">
              {["React", "TypeScript", "Node", "Next.js", "Tailwind", "Jest", "Cypress", "Figma"].map((t) => (
                <Badge key={t} variant="secondary" className="rounded-2xl">{t}</Badge>
              ))}
            </div>
          </CardContent>
        </Card>
        <Card className="rounded-3xl">
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <Avatar className="h-14 w-14">
                <AvatarImage src="https://i.pravatar.cc/140?img=15" alt="Avatar" />
                <AvatarFallback>ME</AvatarFallback>
              </Avatar>
              <div>
                <div className="font-semibold">Your Name</div>
                <div className="text-muted-foreground text-sm">Designer–Developer</div>
              </div>
            </div>
            <div className="mt-4 space-y-2 text-sm">
              <div className="flex justify-between"><span>Location</span><span className="text-muted-foreground">Remote / 🌍</span></div>
              <div className="flex justify-between"><span>Timezone</span><span className="text-muted-foreground">UTC±0</span></div>
              <div className="flex justify-between"><span>Freelance</span><span className="text-muted-foreground">Open</span></div>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}

function Projects() {
  return (
    <section id="projects" className="max-w-6xl mx-auto px-4 py-16">
      <SectionHeading title="Projects" subtitle="Selected work that I enjoyed building" />
      <Tabs defaultValue="all" className="w-full">
        <TabsList className="rounded-2xl">
          <TabsTrigger value="all">All</TabsTrigger>
          <TabsTrigger value="web">Web</TabsTrigger>
          <TabsTrigger value="mobile">Mobile</TabsTrigger>
          <TabsTrigger value="ml">AI/ML</TabsTrigger>
        </TabsList>
        <TabsContent value="all" className="mt-6">
          <ProjectGrid items={projects} />
        </TabsContent>
        <TabsContent value="web" className="mt-6">
          <ProjectGrid items={projects.slice(0, 2)} />
        </TabsContent>
        <TabsContent value="mobile" className="mt-6">
          <ProjectGrid items={[projects[1]]} />
        </TabsContent>
        <TabsContent value="ml" className="mt-6">
          <ProjectGrid items={[projects[2]]} />
        </TabsContent>
      </Tabs>
    </section>
  );
}

function ProjectGrid({ items }: { items: typeof projects }) {
  return (
    <div className="grid md:grid-cols-3 gap-6">
      {items.map((p) => (
        <motion.div key={p.title} variants={fadeIn} initial="hidden" whileInView="show" viewport={{ once: true }}>
          <Card className="rounded-3xl overflow-hidden group">
            <div className="overflow-hidden">
              <img src={p.image} alt={p.title} className="h-44 w-full object-cover transition-transform duration-500 group-hover:scale-105" />
            </div>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>{p.title}</span>
                <div className="flex gap-2">
                  <Button asChild size="icon" variant="ghost" className="rounded-xl" aria-label="Live">
                    <a href={p.href}>
                      <ExternalLink className="h-4 w-4" />
                    </a>
                  </Button>
                  <Button asChild size="icon" variant="ghost" className="rounded-xl" aria-label="Repo">
                    <a href={p.repo}>
                      <Github className="h-4 w-4" />
                    </a>
                  </Button>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <p className="text-muted-foreground text-sm">{p.desc}</p>
              <div className="flex flex-wrap gap-2 mt-3">
                {p.tags.map((t) => (
                  <Badge key={t} variant="outline" className="rounded-2xl">{t}</Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      ))}
    </div>
  );
}

function Skills() {
  return (
    <section id="skills" className="max-w-6xl mx-auto px-4 py-16">
      <SectionHeading title="Skills" subtitle="A snapshot of strengths" />
      <div className="grid md:grid-cols-2 gap-6 items-stretch">
        <Card className="rounded-3xl">
          <CardHeader>
            <CardTitle>Technical Radar</CardTitle>
          </CardHeader>
          <CardContent className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart cx="50%" cy="50%" outerRadius="80%" data={skillsData}>
                <PolarGrid />
                <PolarAngleAxis dataKey="subject" tick={{ fontSize: 12 }} />
                <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fontSize: 10 }} />
                <Radar name="Me" dataKey="A" stroke="#0ea5e9" fill="#0ea5e9" fillOpacity={0.25} />
              </RadarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
        <Card className="rounded-3xl">
          <CardHeader>
            <CardTitle>Toolbox</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-2 gap-3">
            {["React", "Next.js", "TypeScript", "Node.js", "Tailwind", "GraphQL", "Jest", "Cypress", "Docker", "Figma"].map((t) => (
              <Badge key={t} className="justify-center py-2 rounded-2xl" variant="secondary">{t}</Badge>
            ))}
          </CardContent>
        </Card>
      </div>
    </section>
  );
}

function Experience() {
  return (
    <section id="experience" className="max-w-6xl mx-auto px-4 py-16">
      <SectionHeading title="Experience" subtitle="Recent roles & impact" />
      <div className="relative">
        <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-px bg-border" aria-hidden />
        <div className="space-y-8">
          {experience.map((e, i) => (
            <motion.div key={e.role} variants={fadeIn} initial="hidden" whileInView="show" viewport={{ once: true }} className={`grid md:grid-cols-2 gap-6 ${i % 2 === 0 ? "md:pr-10" : "md:pl-10 md:col-start-2"}`}>
              <Card className="rounded-3xl">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>{e.role}</span>
                    <Badge className="rounded-2xl" variant="outline">{e.period}</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-muted-foreground mb-2">{e.company}</div>
                  <ul className="list-disc list-inside space-y-1 text-sm">
                    {e.points.map((p) => (
                      <li key={p}>{p}</li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Contact() {
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const payload = Object.fromEntries(fd.entries());
    // Why: demo UX feedback instead of a dead form submission.
    alert("Thanks! I will get back to you.\n\n" + JSON.stringify(payload, null, 2));
    e.currentTarget.reset();
  };

  return (
    <section id="contact" className="max-w-6xl mx-auto px-4 py-16">
      <SectionHeading title="Contact" subtitle="Let’s build something great together" />
      <Card className="rounded-3xl">
        <CardContent className="p-6">
          <form onSubmit={handleSubmit} className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-medium" htmlFor="name">Name</label>
              <Input id="name" name="name" placeholder="Ada Lovelace" required className="rounded-2xl" />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium" htmlFor="email">Email</label>
              <Input id="email" type="email" name="email" placeholder="ada@example.com" required className="rounded-2xl" />
            </div>
            <div className="md:col-span-2 space-y-2">
              <label className="text-sm font-medium" htmlFor="message">Message</label>
              <Textarea id="message" name="message" placeholder="Tell me about your project…" rows={6} required className="rounded-2xl" />
            </div>
            <div className="md:col-span-2 flex justify-end">
              <Button type="submit" size="lg" className="rounded-2xl">Send Message</Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t">
      <div className="max-w-6xl mx-auto px-4 py-10 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="text-sm text-muted-foreground">© {new Date().getFullYear()} Your Name. All rights reserved.</div>
        <div className="flex gap-2">
          <Button asChild size="icon" variant="ghost" className="rounded-xl">
            <a href="#"><Github className="h-4 w-4" /></a>
          </Button>
          <Button asChild size="icon" variant="ghost" className="rounded-xl">
            <a href="#"><Linkedin className="h-4 w-4" /></a>
          </Button>
          <Button asChild size="icon" variant="ghost" className="rounded-xl">
            <a href="#contact"><Mail className="h-4 w-4" /></a>
          </Button>
        </div>
      </div>
    </footer>
  );
}

export default function Portfolio() {
  const { enabled, setEnabled } = useDarkMode();
  return (
    <TooltipProvider>
      <div className="min-h-screen bg-background text-foreground">
        <Navbar onToggleTheme={() => setEnabled((v) => !v)} />
        <Hero />
        <About />
        <Projects />
        <Skills />
        <Experience />
        <Contact />
        <Footer />
      </div>
    </TooltipProvider>
  );
}
